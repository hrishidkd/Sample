package com.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.DaoOperations;
import com.table.Registration;

public class UpdateRole extends HttpServlet {

	public UpdateRole() {

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		DaoOperations obj = new DaoOperations();

		Registration reg = obj.viewTempUserDetails(request.getParameter("t7"));
		System.out.println("Registration obj : " + reg);
		String role = request.getParameter("role");
		System.out.println("Role : " + role);

		obj.addUser(reg.geteId(), reg.getName(), reg.getName(), reg.getPassword(), reg.getEmail(),
				reg.getMobileNumber(), role);

		response.sendRedirect("adminDemo.jsp");

	}

}
