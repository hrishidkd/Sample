package com.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.DaoOperations;

public class Registration extends HttpServlet {

    public Registration() {

    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		DaoOperations obj = new DaoOperations();
		String name = request.getParameter("t1");
		String username = request.getParameter("t2");
		String password = request.getParameter("t3");
		String email = request.getParameter("t5");
		String mobileNumber = request.getParameter("t6");

		obj.addTempUser(name, username, password, email, mobileNumber);

		System.out.print("Object successfully added : " + name);
		
		response.sendRedirect("index.jsp");
		
	}

}
