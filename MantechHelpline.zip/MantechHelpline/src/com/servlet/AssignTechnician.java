package com.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.DaoOperations;

public class AssignTechnician extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public AssignTechnician() {
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		DaoOperations obj = new DaoOperations();
		String technician = request.getParameter("technician");
		System.out.println("Technician : " + technician);
		int id = Integer.parseInt(request.getParameter("t1"));
		String status = request.getParameter("status");
		System.out.println("Status : " + status);
		
		obj.changeStatus(id, status);
		obj.assignTechnician(id, technician);

		response.sendRedirect("AssignTechnician.jsp");

	}

}
