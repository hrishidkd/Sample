package com.servlet;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.DaoOperations;

public class UserComplaint extends HttpServlet {

	public UserComplaint() {

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		DaoOperations obj = new DaoOperations();
		String complianeeName = request.getParameter("t2");
		String priority = request.getParameter("priority");
		String department = request.getParameter("department");
		String category = request.getParameter("category");

		obj.createComplaint(complianeeName, new Date(), priority, department, category);

		response.sendRedirect("UserComplaint.jsp");

	}

}
