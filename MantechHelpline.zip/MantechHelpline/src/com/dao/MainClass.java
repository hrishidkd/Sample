package com.dao;

import java.io.IOException;

public class MainClass {

	public static void main(String[] args) throws IOException {

		DaoOperations obj = new DaoOperations();

		if (obj.isValid("mike", "123")) {
			System.out.println("welcome");
		} else {
			System.out.println("wrong password");
		}

		System.out.println(obj.getRole("mike"));

		obj.generatePendingReportByDays();
		obj.generatePendingReportByPriority();

	}

}
